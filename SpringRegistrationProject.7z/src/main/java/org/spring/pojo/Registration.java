package org.spring.pojo;

import java.time.LocalDate;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Registration {
	@NotEmpty(message = "* Please enter firstName!")
	private String firstName;
	@NotEmpty(message = "* Please enter LastName!")
	private String lastName;
	@NotEmpty(message = "* Please enter address!")
	private String address;
	@NotEmpty
	@Email(message = "* Please enter valid email!")
	private String email;
	@DateTimeFormat(pattern = "MM/dd/yyyy")
	@Past(message = "* Please enter valid DoB!")
	private Date dateOfBirth;
	@Size(min = 2, max = 30)
	private String mobileNo;
	private double regFees;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getRegFees() {
		return regFees;
	}

	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	public Registration(String firstName, String lastName, String address, String email, Date dateOfBirth,
			String mobileNo, double regFees) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.regFees = regFees;
	}

	public Registration() {
		super();
	}

	@Override
	public String toString() {
		return "Registration [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", email="
				+ email + ", dateOfBirth=" + dateOfBirth + ", mobileNo=" + mobileNo + ", regFees=" + regFees + "]";
	}

}
