package org.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.spring.pojo.Registration;
import org.spring.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {

	List<User> userList = new ArrayList<User>();

	@RequestMapping("/")
	public String sayWelcome() {
		return "index";
	}

	@RequestMapping("/login")
	public String goToLogin(Model model) {
		model.addAttribute("message", "Welcome to Spring Mvc Login Page");
		return "login";
	}

	@RequestMapping(path = "/loginUser")
	public ModelAndView loginUser(@ModelAttribute("User") User user) {
		ModelAndView modelAndView = new ModelAndView();

		userList.add(new User(1, "Vignesh", "1234"));

		for (User userObject : userList) {
			if (userObject.getUserName().equalsIgnoreCase(user.getUserName())
					&& userObject.getPassword().equalsIgnoreCase(user.getPassword())) {
				modelAndView.setViewName("success");
				modelAndView.addObject("User", user);
				return modelAndView;
			}
		}

		modelAndView.setViewName("failure");
		return modelAndView;
	}

	@RequestMapping("/register")
	public ModelAndView validateLogin() {
		return new ModelAndView("register", "registration", new Registration());

	}

	// We can mention class name inside @ModelAttribute example
	// @ModelAttribute("Registration")
	// or if we want to use cutom name we have to mention in jsp form tag like
	// modelAttribute="registration"

	@RequestMapping("/registerUser")
	public String registerUser(@Valid @ModelAttribute("registration") Registration registration, BindingResult result) {
		if (!result.hasErrors()) {
			System.out.println(registration);

			return "done";
		}
		return "/register";
	}

}
